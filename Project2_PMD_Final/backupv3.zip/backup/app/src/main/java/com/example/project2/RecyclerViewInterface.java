package com.example.project2;

public interface RecyclerViewInterface {
    void OnItemClick(int position);
}